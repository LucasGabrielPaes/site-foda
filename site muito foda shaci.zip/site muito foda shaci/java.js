const builds = {
    ap: {
        titulo: "Shaco AP – Burst Explosivo",
        imagem: "imagens/shaco_splash_centered_43.jpg",
        runas: "Chuva de Lâminas, Impacto Repentino, Globos Oculares, Caçador de Tesouros",
        itens: "Luden, Lich Bane, Morello, Rabadon, Zhonyas",
        feitiços: "ignite + smite",
        dicas: "Use caixas + clone para explodir o inimigo instantaneamente."
    },

    ad: {
        titulo: "Shaco AD – One-Shot Crítico",
        imagem: "imagens/LPL-2021-Shaco.jpg",
        runas: "Agilidade nos Pés, Triunfo, Golpe de Misericórdia",
        itens: "Youmuu, Gume do Infinito, Draktharr, Lord Dominik",
        feitiços: "ignite + Smite",
        dicas: "Entre invisível e delete qualquer carry com o crítico garantido."
    },

    tank: {
        titulo: "Shaco Tank/Troll – O Palhaço Imortal",
        imagem: "imagens/how to play shaco in league of legends-b0ec04155da1.webp",
        runas: "Pós-choque, Osso Revestido, Inabalável",
        itens: "Coração de Aço, Jak'Sho, Placa Gargolítica, Couraça do Defunto",
        feitiços: "Ghost + Ignite",
        dicas: "O objetivo é provocar o time inimigo inteiro e não morrer nunca."
    }
};

function mostrarBuild(tipo) {
    const b = builds[tipo];
    document.getElementById("buildBox").innerHTML = `
        <img src="${b.imagem}" class="build-image" alt="Imagem da build ${b.titulo}">
        
        <h2 class="text-3xl font-bold text-red-300 mb-4">${b.titulo}</h2>

        <p><strong>Runas:</strong> ${b.runas}</p>
        <p><strong>Itens principais:</strong> ${b.itens}</p>
        <p><strong>Feitiços:</strong> ${b.feitiços}</p>

        <div class="mt-4 p-4 bg-zinc-700 rounded-lg">S
            <p>${b.dicas}</p>
        </div>
    `;
}